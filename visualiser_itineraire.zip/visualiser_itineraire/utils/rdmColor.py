import random

def rdmColor() :
    return random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)