import pygame
import pandas as pd

# on définit la fonction ecran qui prend en paramètre l'emprise
def ecran(emprise):

    # x_min est le plus petit nombre du premier tuple !!! À MODIFIER
    x_min = min(emprise[0])
    # x_max est le plus grand nombre du premier tuple !!! À MODIFIER
    x_max = max(emprise[0])
    # y_min est le plus petit nombre du deuxième tuple !!! À MODIFIER
    y_min = min(emprise[1])
    # y_max est le plus grand nombre du deuxième tuple !!! À MODIFIER
    y_max = max(emprise[1])

    # on calcul de delta x_min et x_max
    delta_x = x_max - x_min
    # on calcul le delta entre y_min et y_max
    delta_y = y_max - y_min

    # si delta x est plus grand que detla y
    if delta_x >= delta_y:
        # on définit que le delta_x devra renvoyé une taille d'écran de 900
        delta_x_ecran = 900
        # on fait un produit en croix pour trouver delta_y_ecran
        # simplifié : y de notre écran = y * 900 / x
        delta_y_ecran = delta_y * delta_x_ecran / delta_x
        # la fonction retourn un tuple avec delta_x_ecran et delta_y_ecran
        return (delta_x_ecran, delta_y_ecran)
    # si delta y est plus grand que delta x
    else:
        # on définit que le delta_y_ecran devra renvoyé une taille d'écran de 900
        delta_y_ecran = 900
        # on fait notre produit en croix pour trouver delta_x_ecran
        # simplifié : x de notre écran = x * 900 / y
        delta_x_ecran = delta_x * delta_y_ecran / delta_y
        # on retourne un tuple avec delta_x_ecran et delta_y_ecran
        return (delta_x_ecran, delta_y_ecran)