import pandas as pd

def emprise_coord(df,X,Y):

    # calcule des max et min de "X" et "Y"
    x_min, x_max = df[X].min()-((df[X].max() - df[X].min())*1.25), df[X].max() +((df[X].max() - df[X].min())*1.25)
    y_min, y_max = df[Y].min()-((df[Y].max() - df[Y].min())*1.25), df[Y].max()+((df[Y].max() - df[Y].min())*1.25)

    # on calcul de delta x_min et x_max
    delta_x = x_max - x_min
    # on calcul le delta entre y_min et y_max
    delta_y = y_max - y_min

    while delta_y * 900 / delta_x < 350 :
        y_max = y_max + (y_max*0.1)
        delta_y = y_max - y_min


    # Retourner les tuples
    return ((x_min, x_max), (y_min, y_max))

def fusionner_emprises(emprise1, emprise2):
    x1_min, x1_max = emprise1[0]
    y1_min, y1_max = emprise1[1]

    x2_min, x2_max = emprise2[0]
    y2_min, y2_max = emprise2[1]

    x_min = min(x1_min, x2_min)
    x_max = max(x1_max, x2_max)
    y_min = min(y1_min, y2_min)
    y_max = max(y1_max, y2_max)

    return ((x_min, x_max), (y_min, y_max))