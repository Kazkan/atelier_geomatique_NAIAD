import pygame 
import pygame_test as pt

# import de la variables dimension_ecran pour le placement des boutons
dimension_ecran = pt.dimension_ecran

# Fonction pour dessiner les boutons
def create_rects(dimension_ecran):
    # marge_rect est un tupple de 4 valeurs qui définissent la position et la taille du panneau de controle
    # magre_rect = pygame.Rect(x, y, z, k)
    # x = horizontal, y = vertical, z = contour largeur, k = contour hauteur

    # le panneau de controle fais la taille de l'écran en hauteur et garde une marge de 130 pixels à droite
    marge_rect = pygame.Rect(dimension_ecran[0] - 130, 540, 130, dimension_ecran[1])
    #marge_rect = pygame.Rect(dimension_ecran[0] - 130, 0, 130, dimension_ecran[1])

    # les boutons contenus dans le panneau de controle
    play_rect = pygame.Rect(dimension_ecran[0] - 115, dimension_ecran[1] - 180, 105, 50)
    pause_rect = pygame.Rect(dimension_ecran[0] - 115, dimension_ecran[1] - 120, 105, 50)
    quit_rect = pygame.Rect(dimension_ecran[0] - 115, dimension_ecran[1] - 60, 105, 50)

    # avancer et reculer sont placés cote à cote
    avance_rect = pygame.Rect(dimension_ecran[0] - 60, dimension_ecran[1] - 240, 50, 50)
    recule_rect = pygame.Rect(dimension_ecran[0] - 115, dimension_ecran[1] - 240, 50, 50)
    date_rect = pygame.Rect(dimension_ecran[0] - 115, dimension_ecran[1] - 300, 105, 50)

    return marge_rect, play_rect, pause_rect, quit_rect, avance_rect, recule_rect, date_rect