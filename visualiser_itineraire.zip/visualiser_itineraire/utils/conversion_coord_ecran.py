def convert_coords(x, y, emprise, ecran):
    #creation des variables de x min etc
    x_min, x_max = emprise[0]
    y_min, y_max= emprise[1]
    delta_x = x_max - x_min
    delta_y = y_max - y_min
   # création des facteurs d'échelle
    screen_x = int((x - x_min) * ecran[0] / delta_x)
    screen_y = int((y_max - y) * ecran[1] / delta_y)  # Inversion de l'axe Y pour Pygame

    return (screen_x, screen_y)

def convert_coords_hors_emprise(x, y, emprise, dimension_ecran):
    """
    Convertit un point (x, y) en pixels, même s'il est en dehors de l'emprise.
    Retourne une position écran potentiellement négative ou > dimension_ecran.
    """
    x_min, x_max = emprise[0]
    y_min, y_max = emprise[1]
    delta_x = x_max - x_min
    delta_y = y_max - y_min

    ecran_x = (x - x_min) * dimension_ecran[0] / delta_x
    ecran_y = (y_max - y) * dimension_ecran[1] / delta_y  # inversion axe Y

    return int(ecran_x), int(ecran_y)
