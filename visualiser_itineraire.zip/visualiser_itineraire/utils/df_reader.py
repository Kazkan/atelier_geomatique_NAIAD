import pandas as pd
import random

def rdmColor() :
    return random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)

def reader(df,id:str,temps:str,coord_x:float,coord_y:float, csv_crs,raster_crs):
    
    # création dictionnaire de sortie
    output = {}

    # récupération des identifiants unique
    noms=df[id].unique().tolist()
    # récupération de la date la plus ancienne
    date_min = df[temps].min()
    # récupération de la date la plus récente
    date_max = df[temps].max()

    # boucle de récupération des autres données
    i=1
    for nom_drone in noms : 
        # création des listes transitoires
        list_temps = []
        list_x = []
        list_y = []
        # filtre et tri des données correspondant au drone examiné
        data_drone = df[df[id] == nom_drone].sort_values(by=temps)
        for element in data_drone.iterrows():
            #ajout des elements d'un drone dans les listes transitoires
            list_temps.append(element[1][temps])
            list_x.append(element[1][coord_x])
            list_y.append(element[1][coord_y])

        # vérifie si date min se trouve dans la liste de date
        if date_min not in list_temps:
            # si non, on l'ajoute
            list_temps.insert(0,date_min)
            # on cré un jeu de coordonnée associé correspondant à la premiere position du drone
            list_x.insert(0, data_drone.iloc[0][coord_x])
            list_y.insert(0, data_drone.iloc[0][coord_y])
        # vérifie si date max se trouve dans la liste de date
        if date_max not in list_temps:
            # si non, on l'ajoute
            list_temps.append(date_max)
            # on cré un jeu de coordonnée associé correspondant à la derniere position du drone
            list_x.append(data_drone.iloc[-1][coord_x])
            list_y.append(data_drone.iloc[-1][coord_y])

        # ajout des données du drone dans le dict output
        output['drone '+str(i)] = {'id' : nom_drone,'temps' : list_temps, 'x' : list_x, 'y' : list_y, 'itineraire' : [] ,'couleur':rdmColor()} 
        i+=1
    return output
        
# structure des données : {'drone 1': {'id': 'Drone 1', 'temps': [0, 1, 2, etc], 'x': [0, 1, 2,etc ], 'y': [0, 1, 2, etc],'itineraire' : [], 'couleur' : (250,250,250)}, 'drone 2': etc}}
