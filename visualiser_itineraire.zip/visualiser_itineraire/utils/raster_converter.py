import rasterio
import numpy as np
import matplotlib.pyplot as plt
import os

def convert_tif_to_png(tif_path):

    png_path = os.path.splitext(tif_path)[0] + ".png"

    with rasterio.open(tif_path) as src:
        count = src.count

        if count >= 3:
            # Lecture des 3 bandes R, G, B
            r = src.read(1).astype(np.float32)
            g = src.read(2).astype(np.float32)
            b = src.read(3).astype(np.float32)

            # Normalisation automatique
            def normalize(x):
                return (x - x.min()) / (x.max() - x.min())

            rgb = np.stack([normalize(r), normalize(g), normalize(b)], axis=-1)
        else:
            # Image en niveaux de gris (1 bande)
            gray = src.read(1).astype(np.float32)
            rgb = (gray - gray.min()) / (gray.max() - gray.min())

    # Sauvegarde en PNG
    plt.imsave(png_path, rgb, cmap=None)
    
    return png_path