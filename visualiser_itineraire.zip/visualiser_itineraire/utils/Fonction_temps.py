import pandas as pd
import numpy as np

def interpoler_positions_plage(df, temps_debut, temps_fin, id_drone, date, X, Y, intervalle, unite='secondes'):
    """
    Interpole les positions des drones pour une plage de temps à intervalles réguliers,
    en forçant des positions fixes avant/après la période réelle de chaque drone.
    """
    # Convertir les timestamps en datetime si ce n'est pas déjà fait
    df[date] = pd.to_datetime(df[date])
    temps_debut = pd.to_datetime(temps_debut)
    temps_fin = pd.to_datetime(temps_fin)

    # Mapping des unités de temps vers les codes de fréquence pandas
    unites_freq = {
        'secondes': 'S',
        'minutes': 'T',
        'heures': 'H',
        'jours': 'D',
        'semaines': 'W',
        'mois': 'M',
        'années': 'Y'
    }

    if unite not in unites_freq:
        raise ValueError(f"Unité '{unite}' non reconnue. Utilisez une des suivantes: {', '.join(unites_freq.keys())}")

    # Créer une liste de tous les timestamps à interpoler
    freq = f'{intervalle}{unites_freq[unite]}'
    plage_temps = pd.date_range(start=temps_debut, end=temps_fin, freq=freq)

    # Identifier tous les drones uniques
    drones = df[id_drone].unique()
    resultats = []

    for drone in drones:
        df_drone = df[df[id_drone] == drone].sort_values(date).copy()

        if df_drone.empty:
            continue

        # Étendre les positions du drone pour couvrir toute la plage [temps_debut, temps_fin]
        drone_debut = df_drone[date].min()
        drone_fin = df_drone[date].max()

        # ➕ Ajouter ligne de début si nécessaire
        if temps_debut < drone_debut:
            ligne_debut = df_drone.iloc[0].copy()
            ligne_debut[date] = temps_debut
            df_drone = pd.concat([pd.DataFrame([ligne_debut]), df_drone])

        # ➕ Ajouter ligne de fin si nécessaire
        if temps_fin > drone_fin:
            ligne_fin = df_drone.iloc[-1].copy()
            ligne_fin[date] = temps_fin
            df_drone = pd.concat([df_drone, pd.DataFrame([ligne_fin])])

        # Réindexer avec la plage complète et interpoler
        df_drone = df_drone.set_index(date)
        index_complet = df_drone.index.union(plage_temps).sort_values()
        df_reindexe = df_drone.reindex(index_complet)

        # Interpolation linéaire
        df_interpol = df_reindexe.interpolate(method='linear', limit_direction='both')

        # Extraction des valeurs interpolées aux timestamps d'intérêt
        for timestamp in plage_temps:
            if timestamp in df_interpol.index:
                x = df_interpol.loc[timestamp, X]
                y = df_interpol.loc[timestamp, Y]
                resultats.append([drone, timestamp, x, y])

    return pd.DataFrame(resultats, columns=[id_drone, date, X, Y])