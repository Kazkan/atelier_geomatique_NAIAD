import rasterio
from rasterio.windows import from_bounds
from rasterio.transform import Affine
from rasterio.errors import WindowError
import numpy as np
import os

def extraire_raster_emprise(raster_path, emprise_csv):

    path_img = os.path.dirname(os.path.abspath(__file__))[:-5]
    path_img = path_img.replace("\\",'/')

    with rasterio.open(raster_path) as src:
        bounds_raster = src.bounds  # bounds: left, bottom, right, top

        # Emprise raster
        x_min_rast, y_min_rast, x_max_rast, y_max_rast = bounds_raster.left, bounds_raster.bottom, bounds_raster.right, bounds_raster.top

        # Emprise CSV
        (x_min_csv, x_max_csv), (y_min_csv, y_max_csv) = emprise_csv

        # Intersection entre raster et CSV
        x_min = max(x_min_rast, x_min_csv)
        x_max = min(x_max_rast, x_max_csv)
        y_min = max(y_min_rast, y_min_csv)
        y_max = min(y_max_rast, y_max_csv)

        if x_min >= x_max or y_min >= y_max:
            raise ValueError("L'emprise CSV ne croise pas le raster. Pas d'intersection possible.")

        try:
            window = from_bounds(x_min, y_min, x_max, y_max, src.transform).round_offsets().round_lengths()
            data = src.read(window=window)
            transform = src.window_transform(window)

            profile = src.profile
            profile.update({
                'height': window.height,
                'width': window.width,
                'transform': transform
            })

            output_path = path_img + "data/img.tif"
            with rasterio.open(output_path, 'w', **profile) as dst:
                dst.write(data)

            return output_path

        except WindowError as e:
            raise RuntimeError(f"Erreur lors de l'extraction raster : {e}")