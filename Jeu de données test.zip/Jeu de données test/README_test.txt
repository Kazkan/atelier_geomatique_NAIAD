Les fichiers suivant permettent de tester différents cas de figure que le plugin visualiser_itineraire peut avoir à gérer. Cela permet de s'assurer du bon fonctionnement des divers fonctions du plugin. 

1_deplacements_drones_wgs84.csv
Permet de vérifier le fonctionnement du plugin avec des drones dont les plages horaires des enregistrements sont différentes

2_GDEM-10km-colorized.tif
Permet de vérifier le fonctionnement du plugin avec un fond de plan en plus des itinéraires de drones

3_deplacements_drones_lambIV.csv
4_GDEM-10km-colorized_epsg_6933.tif
Permettent de vérifier le fonctionnement du plugin lorsque les données des drones et de fond de plan ont des systemes de coordonnées de références différents

5_deplacements_drones_wgs84_temps_decal.csv
Permet de férifier le fonctionnement du plugin avec des drones dont les fréquences d'enregistrement sont différentes

6_GDEM-10km-colorized_wgs84_masque.tif
Permet de vérifier le fonctionnement du plugin avec un fond de plan dont l'emprise n'englobe pas totalement celle des itinéraires de drones

7_deplacements_drones.csv
permet de tester le fonctionnement du plugin sur une aire géographique différentes et beaucoup plus large et de controler la mise à jour de l'échelle graphique
